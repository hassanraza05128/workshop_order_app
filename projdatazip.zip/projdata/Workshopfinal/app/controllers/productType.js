//models
var Producttype = require('../models/producttype');

var producttypereg_get  =    function(req, res, next){
    res.render('admin/producttype/register',{
        'error':req.flash('error'),
        'msg':req.flash('msg'),
        'old_name':req.flash('old_name',req.body.name),
    });
}
var producttypereg_post     =   function(req, res, next){
    var producttypedata = {'name': req.body.name,};

    // flash data for reset values on redirectback
    req.flash('error',true);
    req.flash('old_name',req.body.name);

    if(producttypedata.name === ''){
        req.flash('msg', 'Missing Fields.');
        res.redirect('producttypereg');
    }else{
        Producttype.producttype.findOneWithDeleted({name:new RegExp('^' + req.body.name + '$', 'i')}, function (err, existing) {
            if(existing){
                req.flash('error',true);
                req.flash('msg','Already Register With Same Name');
                res.redirect('producttypereg');
            }else{
                Producttype.create(producttypedata, function(err, newproducttype){
                    if(err) throw err;
                    req.flash('error', false);
                    req.flash('msg', 'New Product Type has Registered.');
                    res.redirect('producttypereg');
                });
            }
        });
    }
}
var allproducttypes     =   function(req, res, next){
    var resData={error:{},table:[]};
    resData.redirect_error  =   req.flash('redirect_error');
    resData.redirect_msg    =   req.flash('redirect_msg');
    Producttype.producttype.findWithDeleted({},function (err, producttype) {
        if (err!==null){
            resData.error=err;
        }else{
            resData.table=producttype;
        }
        //res.send(resData);
        res.render('admin/producttype/table', resData);
    });
}
var producttypedelete   = function (req, res, next) {

    var id=req.query.id;
    if(!id)redirect('/admin/allproducttypes');
    req.flash('redirect_error',true);
    Producttype.findById(id,function (err, producttype) {
        if(err){
            req.flash('redirect_msg',err.name+' : '+err.message);
        }else {
            //console.log(material);
            producttype.delete(function (err) {
                if(err){
                    req.flash('redirect_msg',err.name+' : '+err.message);
                }else {
                    req.flash('redirect_error', false);
                    req.flash('redirect_msg', 'Operation Successful');
                }
            });
        }
    });
    res.redirect('/admin/allproducttypes');
}
var producttyperestore  =function (req, res, next) {
    var id=req.query.id;
    if(!id)redirect('/admin/allproducttypes');
    req.flash('redirect_error',true);
    Producttype.producttype.findOneWithDeleted({_id:id},function (err, producttype) {
        if(err){
            req.flash('redirect_msg',err.name+' : '+err.message);
        }else {
            //console.log(material);
            producttype.restore(function (err) {
                if(err){
                    req.flash('redirect_msg',err.name+' : '+err.message);
                }else {
                    req.flash('redirect_error', false);
                    req.flash('redirect_msg', 'Operation Successful');
                }
            });
        }

    });
    res.redirect('/admin/allproducttypes');
}
var producttypeupdate_get   = function (req, res, next) {
    var resData={
        redirect_error : req.flash('redirect_error'),
        redirect_msg : req.flash('redirect_msg'),
    };
    var  id = req.query.id;
    if(!id)res.redirect('/admin/allproducttypes');
    req.flash('redirect_error', true);
    Producttype.findById(id,function (err, data) {
        if(err){
            req.flash('redirect_msg',err);
            res.redirect('/admin/allproducttypes');
        }else{
            req.flash('redirect_error',false);
            // data.redirect_error =resData.redirect_error;
            // data.redirect_msg   =resData.redirect_msg;
            resData.id=data._id;
            resData.name=data.name;
            //res.send(resData);
            res.render('admin/producttype/edit', resData);
        }
    });
}
var producttypeupdate_post  = function (req, res, next) {
    if(!req.body.id)res.redirect('/admin/allproducttypes');
    req.flash('redirect_error', true);

    //check if name already exist
    Producttype.producttype.findOneWithDeleted({name:new RegExp('^' + req.body.name + '$', 'i')},function (err, data) {
        if(data){
            if(data._id === req.body.id){
                req.flash('redirect_msg', 'Same So no change');
                res.redirect('/admin/allproducttypes');
            }
            req.flash('redirect_msg', 'Already Exist this Product type So try some thing else');
            res.redirect('/admin/allproducttypes');
        }
    });
    //check and update product type by id
    Producttype.findById(req.body.id,function (err, data) {
        if(err){
            req.flash('redirect_msg',"data not find");
            res.redirect('/admin/allproducttypes');
        }else{
            data.name = req.body.name;
            data.save(function (err) {
                if(err){
                    req.flash('redirect_msg', err.name+' : '+err.message);
                }else{
                    req.flash('redirect_error', true);
                    req.flash('redirect_msg', 'Operation successfull');
                }
            });
            res.render('admin/producttype/edit',data);
        }
    });
}


module.exports={
    producttypereg_get,
    producttypereg_post,
    allproducttypes,
    producttypedelete,
    producttyperestore,
    producttypeupdate_get,
    producttypeupdate_post,
};