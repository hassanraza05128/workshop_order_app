'use strict';

var Mongoose  = require('mongoose');
var mongoose_delete = require('mongoose-delete');
var timestamp = require('mongoose-timestamp');
const DEFAULT_USER_PICTURE = "/img/user.jpg";

/**
 * Each connection object represents a client connected through a unique socket.
 *
 */
var clientSchema = new Mongoose.Schema({
    name: { type: String, required: true, maxlength: 100, minlength: 3, lowercase: true,trim: true, },
    phoneno: { type: String, required: true, maxlength: 15, minlength: 11, },
    address: { type: String, maxlength: 500, minlength: 5,trim: true, },
    cnic: { type: String, maxlength:15, minlength:13,},
    picture: { type: String, default:DEFAULT_USER_PICTURE, maxlength:500, },
    country: { type: String, required: true, maxlength:100, minlength:3,  },
    // postalCode: { type: String },
    city: { type: String, required: true, maxlength:100, minlength:3, },
});

//plugin addings
clientSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: true, });
clientSchema.plugin(timestamp);
clientSchema.pre('save', function(next) {
    var client = this;
    // ensure client picture is set
    if(!client.picture){
        client.picture = DEFAULT_USER_PICTURE;
    }
    next();
});

var cusModel = Mongoose.model('client', clientSchema);

module.exports = cusModel;