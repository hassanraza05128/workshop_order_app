'use strict';

var Mongoose  = require('mongoose');
var mongoose_delete = require('mongoose-delete');
var timestamp = require('mongoose-timestamp');
var autopopulate = require('mongoose-autopopulate');
//var autoIncrement = require('mongoose-auto-increment');
//var autoIncrement = require('mongoose-sequence')(Mongoose)
var Schema=Mongoose.Schema;
var ObjectId=Schema.Types.ObjectId;


// var RawProductSchema=new Mongoose.Schema({
//     rawProduct=
// });

var CostEstimationSchema = new Mongoose.Schema({
    type:{ type: String, required: true,lowercase: true,trim: true, },

    

    // thumb:{ type: String, required: true, maxlength:100 },
    // name:{ type: String, required: true, maxlength:100 },
    // mimetype:{ type: String, required: true, maxlength:50 },
    // fullpath:{ type: String, required: true, maxlength:100 },
    // path:{ type: String, required: true, maxlength:100 },
    // size:{ type: Number, required: true, },

});

var contentSchema = new Mongoose.Schema({
    orignalname:{ type: String, required: true, maxlength:100 },
    thumb:{ type: String, required: true, maxlength:100 },
    name:{ type: String, required: true, maxlength:100 },
    mimetype:{ type: String, required: true, maxlength:50 },
    fullpath:{ type: String, required: true, maxlength:100 },
    path:{ type: String, required: true, maxlength:100 },
    size:{ type: Number, required: true, },
    
});

var productSchema = new Mongoose.Schema({
    designid: { type: Number, required: true, unique: true, max:99999 , min:10000},
    name:{type: String, lowercase: true, trim: true, maxlength:100},
    discription:{type:String, trim: true, maxlength:500},
    material: { type: ObjectId, ref:'material', autopopulate:{maxdept:2,select:'name'}, required: true },
    type: { type: ObjectId, ref:'producttype',autopopulate:{maxdept:2,select:'name'}, required: true },
    contents: [{type: contentSchema,}],

    parameters:[{ type: ObjectId, ref:'parameter',autopopulate:true}],
    rawitems:[{ type: ObjectId, ref:'material' , autopopulate:true}],

    //regular
});

//plugin addings
productSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: true, });
productSchema.plugin(timestamp);
productSchema.plugin(autopopulate);
//productSchema.plugin(autoIncrement, {inc_field: 'designid'});

var productModel = Mongoose.model('product', productSchema);
module.exports = productModel;