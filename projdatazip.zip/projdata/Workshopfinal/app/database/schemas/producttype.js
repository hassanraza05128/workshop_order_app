'use strict';

var Mongoose  = require('mongoose');
var mongoose_delete = require('mongoose-delete');
var timestamp = require('mongoose-timestamp');


var producttypeSchema = new Mongoose.Schema({
    name: { type: String, required: true, maxlength: 100, minlength: 3, lowercase: true,trim: true, },
    //tags:{},
});

//plugin addings
producttypeSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: true, });
producttypeSchema.plugin(timestamp);

var producttypeModel = Mongoose.model('producttype', producttypeSchema);
module.exports = producttypeModel;